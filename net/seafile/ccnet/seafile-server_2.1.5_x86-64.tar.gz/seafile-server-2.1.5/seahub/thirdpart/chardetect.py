#!/usr/bin/python2.6
# EASY-INSTALL-SCRIPT: 'chardet==2.1.1','chardetect.py'
__requires__ = 'chardet==2.1.1'
import pkg_resources
pkg_resources.run_script('chardet==2.1.1', 'chardetect.py')
