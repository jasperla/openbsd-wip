#!/bin/sh

. setenv.sh

python manage.py test fts

